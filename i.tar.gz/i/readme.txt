make clean
make all
make run
注意：make run后，需要输入下c然后敲回车键
